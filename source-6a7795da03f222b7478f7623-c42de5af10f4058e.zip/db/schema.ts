import { integer, pgTable, text, timestamp } from 'drizzle-orm/pg-core'

export const searchUsage = pgTable('search_usage', {
  visitorKey: text('visitor_key').primaryKey(),
  searches: integer('searches').notNull().default(0),
  createdAt: timestamp('created_at').notNull().defaultNow(),
  updatedAt: timestamp('updated_at').notNull().defaultNow(),
})
