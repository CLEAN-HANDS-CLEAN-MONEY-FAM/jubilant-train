# ALLMINE Project Guide

## Project Overview

ALLMINE is a single-site search application built with TanStack Start and deployed on Netlify. The browser sends search requests to a same-origin Netlify Function, which queries public search sources and records complimentary usage in Netlify Database.

## Architecture

- `src/routes/index.tsx` contains the complete interactive search page and client-side state.
- `src/styles.css` contains the global visual system, responsive layouts, and interaction states.
- `src/routes/__root.tsx` defines document metadata and the root HTML shell.
- `netlify/functions/search.mts` validates requests, enforces limits, aggregates sources, and returns normalized results.
- `db/schema.ts` defines persistent tables with Drizzle ORM.
- `db/index.ts` creates the Netlify Database client.
- `netlify/database/migrations/` contains generated schema migrations applied by Netlify.
- `drizzle.config.ts` directs Drizzle migrations to Netlify's required directory.

## Coding Conventions

- Use TypeScript with strict types and type-only imports where appropriate.
- Keep serverless APIs in `netlify/functions/` and use standard Web `Request` and `Response` objects.
- Render external data through React values; do not introduce raw HTML rendering.
- Use CSS variables from `src/styles.css` for color, type, and surface consistency.
- Use Lucide React for interface icons instead of hand-authored icon SVGs.
- Preserve keyboard focus states, reduced-motion support, and mobile layouts.

## Data and Search Decisions

Search usage must remain persistent. Do not replace Netlify Database with process memory, browser-only counters, JSON files, or external databases. Schema changes require both an update to `db/schema.ts` and a generated migration created with `npx drizzle-kit generate --name <change_name>`.

The search endpoint intentionally uses public Wikipedia and DuckDuckGo APIs and does not require secrets. Requests remain same-origin, so a separate Render service and permissive CORS configuration are unnecessary.

Partner results must stay clearly labeled. The current URLs are partner suggestions rather than tracked affiliate links; do not describe them as revenue-generating until approved affiliate identifiers are configured.

## Common Commands

```bash
pnpm install
pnpm dev
netlify dev --port 8889
npx drizzle-kit generate --name <change_name>
```
