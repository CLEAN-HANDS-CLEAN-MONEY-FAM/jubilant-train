import { createFileRoute } from '@tanstack/react-router'
import {
  ArrowUpRight,
  Database,
  ExternalLink,
  Fingerprint,
  LockKeyhole,
  Search,
  ShieldCheck,
} from 'lucide-react'
import { useState, type FormEvent } from 'react'

export const Route = createFileRoute('/')({
  component: AllmineSearch,
})

type SearchResult = {
  title: string
  snippet: string
  url: string
  source: string
  type: 'reference' | 'instant' | 'related' | 'sponsored'
}

type SearchResponse = {
  success: boolean
  error?: string
  message?: string
  price?: string
  remaining?: number
  results?: SearchResult[]
}

type SearchState = 'idle' | 'loading' | 'success' | 'empty' | 'limit' | 'error'

const suggestions = ['Yellow Quill First Nation', 'privacy tools', 'Canadian history']

function getClientId() {
  const storageKey = 'allmine-client-id'
  const existing = window.localStorage.getItem(storageKey)
  if (existing) return existing

  const generated =
    typeof window.crypto.randomUUID === 'function'
      ? window.crypto.randomUUID()
      : `${Date.now()}-${window.crypto.getRandomValues(new Uint32Array(2)).join('-')}`
  window.localStorage.setItem(storageKey, generated)
  return generated
}

function getHostname(url: string) {
  try {
    return new URL(url).hostname
  } catch {
    return 'external source'
  }
}

function AllmineSearch() {
  const [query, setQuery] = useState('')
  const [results, setResults] = useState<SearchResult[]>([])
  const [state, setState] = useState<SearchState>('idle')
  const [message, setMessage] = useState('')
  const [remaining, setRemaining] = useState(5)

  async function runSearch(searchQuery: string) {
    const trimmedQuery = searchQuery.trim()
    if (!trimmedQuery) {
      setState('error')
      setMessage('Enter a subject, place, person, or question to begin.')
      return
    }

    setQuery(trimmedQuery)
    setState('loading')
    setMessage('Reading independent sources…')
    setResults([])

    try {
      const response = await fetch('/api/search', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ query: trimmedQuery, clientId: getClientId() }),
      })
      const data = (await response.json()) as SearchResponse

      if (response.status === 402 && data.error === 'FREE_LIMIT_REACHED') {
        setState('limit')
        setRemaining(0)
        setMessage(data.message ?? 'The complimentary search limit has been reached.')
        return
      }

      if (!response.ok || !data.success) {
        throw new Error(data.message ?? 'The search matrix did not respond.')
      }

      const nextResults = data.results ?? []
      setResults(nextResults)
      setRemaining(data.remaining ?? remaining)
      setState(nextResults.length > 0 ? 'success' : 'empty')
      setMessage(
        nextResults.length > 0
          ? `${nextResults.length} sources resolved for “${trimmedQuery}”.`
          : `No direct matches surfaced for “${trimmedQuery}”.`,
      )
    } catch (error) {
      setState('error')
      setMessage(
        error instanceof Error
          ? error.message
          : 'The search matrix is temporarily unavailable.',
      )
    }
  }

  function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault()
    void runSearch(query)
  }

  return (
    <main className="site-shell">
      <div className="ambient-grid" aria-hidden="true" />

      <header className="topbar">
        <a className="brand" href="#top" aria-label="ALLMINE home">
          <span className="brand-mark">AM</span>
          <span>
            <strong>ALLMINE</strong>
            <small>Search Matrix</small>
          </span>
        </a>
        <div className="ownership-line">
          <ShieldCheck size={16} aria-hidden="true" />
          <span>Independent · Indigenous-owned</span>
        </div>
      </header>

      <section className="hero" id="top">
        <div className="hero-copy">
          <p className="eyebrow">PROPRIETARY SEARCH MATRIX · V2.0</p>
          <h1>
            Search the open web.
            <span>Keep the signal.</span>
          </h1>
          <p className="hero-description">
            ALLMINE brings public knowledge and instant-answer sources into one
            focused view, without sending the browser to a separate backend.
          </p>

          <div className="owner-card">
            <div className="owner-monogram">MM</div>
            <div>
              <span>Owned and directed by</span>
              <strong>Morley Moses Apooch</strong>
              <small>Yellow Quill First Nation</small>
            </div>
          </div>
        </div>

        <div className="search-console">
          <div className="console-header">
            <div className="console-status">
              <span className="status-dot" />
              CORE ONLINE
            </div>
            <span>{remaining}/5 FREE QUERIES</span>
          </div>

          <form className="search-form" onSubmit={handleSubmit}>
            <label htmlFor="search-query">What are you looking for?</label>
            <div className="search-field">
              <Search size={22} aria-hidden="true" />
              <input
                id="search-query"
                value={query}
                onChange={(event) => setQuery(event.target.value)}
                placeholder="Search a topic, place, or question"
                maxLength={160}
                autoComplete="off"
                disabled={state === 'loading'}
              />
              <button type="submit" disabled={state === 'loading'}>
                {state === 'loading' ? 'Scanning' : 'Initialize'}
                <ArrowUpRight size={18} aria-hidden="true" />
              </button>
            </div>
          </form>

          <div className="suggestions" aria-label="Suggested searches">
            <span>Try:</span>
            {suggestions.map((suggestion) => (
              <button
                type="button"
                key={suggestion}
                onClick={() => void runSearch(suggestion)}
                disabled={state === 'loading'}
              >
                {suggestion}
              </button>
            ))}
          </div>

          <div className="privacy-note">
            <Fingerprint size={19} aria-hidden="true" />
            <p>
              A private device identifier tracks the complimentary allowance.
              No account is required.
            </p>
          </div>
        </div>
      </section>

      <section className="source-strip" aria-label="Search capabilities">
        <div>
          <Database size={18} aria-hidden="true" />
          <span>Reference layer</span>
          <strong>Wikipedia</strong>
        </div>
        <div>
          <Search size={18} aria-hidden="true" />
          <span>Instant-answer layer</span>
          <strong>DuckDuckGo</strong>
        </div>
        <div>
          <LockKeyhole size={18} aria-hidden="true" />
          <span>Request path</span>
          <strong>Netlify secured</strong>
        </div>
      </section>

      <section className="results-section" aria-live="polite">
        <div className="results-heading">
          <div>
            <p className="eyebrow">MATRIX OUTPUT</p>
            <h2>{state === 'idle' ? 'Ready when you are.' : 'Search results'}</h2>
          </div>
          {message && <p className={`response-message ${state}`}>{message}</p>}
        </div>

        {state === 'idle' && (
          <div className="empty-panel">
            <div className="matrix-visual" aria-hidden="true">
              <span />
              <span />
              <span />
              <span />
              <span />
              <span />
            </div>
            <div>
              <span>01 / INPUT</span>
              <h3>One query. Multiple public sources.</h3>
              <p>
                Enter a search above to assemble a concise source list in this
                space. Results open directly at their original publisher.
              </p>
            </div>
          </div>
        )}

        {state === 'loading' && (
          <div className="skeleton-list" aria-label="Loading search results">
            {[0, 1, 2].map((item) => (
              <div className="result-skeleton" key={item}>
                <span />
                <span />
                <span />
              </div>
            ))}
          </div>
        )}

        {state === 'empty' && (
          <div className="notice-card">
            <Search size={28} aria-hidden="true" />
            <h3>Nothing direct surfaced.</h3>
            <p>Try a broader phrase, alternate spelling, or a shorter question.</p>
          </div>
        )}

        {state === 'error' && (
          <div className="notice-card error-card">
            <LockKeyhole size={28} aria-hidden="true" />
            <h3>Connection interrupted.</h3>
            <p>{message}</p>
          </div>
        )}

        {state === 'limit' && (
          <div className="premium-card">
            <div>
              <p className="eyebrow">PREMIUM ACCESS</p>
              <h3>Continue searching with ALLMINE Premium.</h3>
              <p>{message}</p>
            </div>
            <div className="price-block">
              <strong>$99</strong>
              <span>CAD / year</span>
              <small>Enrollment details coming soon</small>
            </div>
          </div>
        )}

        {state === 'success' && (
          <div className="results-list">
            {results.map((result, index) => (
              <article
                className={`result-card ${result.type === 'sponsored' ? 'sponsored' : ''}`}
                key={`${result.url}-${index}`}
              >
                <div className="result-index">{String(index + 1).padStart(2, '0')}</div>
                <div className="result-content">
                  <div className="result-meta">
                    <span>{result.source}</span>
                    <span>{result.type === 'sponsored' ? 'Partner result' : result.type}</span>
                  </div>
                  <h3>
                    <a
                      href={result.url}
                      target="_blank"
                      rel={result.type === 'sponsored' ? 'sponsored nofollow noreferrer' : 'noreferrer'}
                    >
                      {result.title}
                      <ExternalLink size={17} aria-hidden="true" />
                    </a>
                  </h3>
                  <p>{result.snippet}</p>
                  <span className="result-url">{getHostname(result.url)}</span>
                </div>
              </article>
            ))}
          </div>
        )}
      </section>

      <footer>
        <div>
          <strong>ALLMINE</strong>
          <span>Independent search interface</span>
        </div>
        <p>
          Copyright © 2026 Morley Moses Apooch. All rights reserved.
          Developed with assistance from Lumo AI (Proton).
        </p>
      </footer>
    </main>
  )
}
