import { createHash } from 'node:crypto'
import type { Config, Context } from '@netlify/functions'
import { and, eq, lt, sql } from 'drizzle-orm'
import { db } from '../../db/index.js'
import { searchUsage } from '../../db/schema.js'

const FREE_SEARCH_LIMIT = 5
const PREMIUM_PRICE = 99

type SearchResult = {
  title: string
  snippet: string
  url: string
  source: string
  type: 'reference' | 'instant' | 'related' | 'sponsored'
}

type SearchBody = {
  query?: unknown
  clientId?: unknown
}

function json(data: unknown, status = 200) {
  return Response.json(data, {
    status,
    headers: {
      'Cache-Control': 'no-store',
      'Content-Security-Policy': "default-src 'none'; frame-ancestors 'none'",
    },
  })
}

function cleanText(value: string) {
  return value
    .replace(/<[^>]*>/g, '')
    .replace(/&quot;/g, '"')
    .replace(/&#039;/g, "'")
    .replace(/&amp;/g, '&')
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
    .replace(/\s+/g, ' ')
    .trim()
}

function getVisitorKey(clientId: string, context: Context) {
  const identity = `${clientId}|${context.ip ?? 'unknown'}`
  return createHash('sha256').update(identity).digest('hex')
}

async function claimFreeSearch(visitorKey: string) {
  await db
    .insert(searchUsage)
    .values({ visitorKey })
    .onConflictDoNothing({ target: searchUsage.visitorKey })

  const [usage] = await db
    .update(searchUsage)
    .set({
      searches: sql`${searchUsage.searches} + 1`,
      updatedAt: new Date(),
    })
    .where(
      and(
        eq(searchUsage.visitorKey, visitorKey),
        lt(searchUsage.searches, FREE_SEARCH_LIMIT),
      ),
    )
    .returning({ searches: searchUsage.searches })

  return usage?.searches ?? null
}

async function fetchWikipedia(query: string): Promise<SearchResult[]> {
  const params = new URLSearchParams({
    action: 'query',
    list: 'search',
    srsearch: query,
    srlimit: '8',
    format: 'json',
    origin: '*',
  })

  try {
    const response = await fetch(`https://en.wikipedia.org/w/api.php?${params}`, {
      signal: AbortSignal.timeout(7000),
      headers: { 'Api-User-Agent': 'ALLMINE/2.0 (Netlify search interface)' },
    })
    if (!response.ok) return []

    const data = (await response.json()) as {
      query?: { search?: Array<{ title: string; snippet: string }> }
    }

    return (data.query?.search ?? []).map((item) => ({
      title: item.title,
      snippet: cleanText(item.snippet),
      url: `https://en.wikipedia.org/wiki/${encodeURIComponent(item.title.replace(/ /g, '_'))}`,
      source: 'Wikipedia',
      type: 'reference',
    }))
  } catch {
    return []
  }
}

async function fetchDuckDuckGo(query: string): Promise<SearchResult[]> {
  const params = new URLSearchParams({
    q: query,
    format: 'json',
    no_html: '1',
    no_redirect: '1',
    skip_disambig: '0',
  })

  try {
    const response = await fetch(`https://api.duckduckgo.com/?${params}`, {
      signal: AbortSignal.timeout(7000),
    })
    if (!response.ok) return []

    const data = (await response.json()) as {
      AbstractText?: string
      AbstractURL?: string
      Heading?: string
      RelatedTopics?: Array<{
        FirstURL?: string
        Text?: string
        Topics?: Array<{ FirstURL?: string; Text?: string }>
      }>
    }
    const results: SearchResult[] = []

    if (data.AbstractText && data.AbstractURL) {
      results.push({
        title: data.Heading || query,
        snippet: cleanText(data.AbstractText),
        url: data.AbstractURL,
        source: 'DuckDuckGo',
        type: 'instant',
      })
    }

    const related = (data.RelatedTopics ?? []).flatMap((topic) =>
      topic.Topics ?? [topic],
    )

    for (const topic of related.slice(0, 4)) {
      if (!topic.FirstURL || !topic.Text) continue
      const [title] = topic.Text.split(' - ')
      results.push({
        title: title || query,
        snippet: cleanText(topic.Text),
        url: topic.FirstURL,
        source: 'DuckDuckGo',
        type: 'related',
      })
    }

    return results
  } catch {
    return []
  }
}

function addPartnerResults(query: string, results: SearchResult[]) {
  const normalizedQuery = query.toLowerCase()
  const partners = [
    {
      keywords: ['laptop', 'phone', 'tech', 'computer'],
      title: 'Technology deals',
      snippet: 'Browse current laptops, phones, and accessories on Amazon Canada.',
      url: 'https://www.amazon.ca/s?k=laptop',
    },
    {
      keywords: ['book', 'read', 'novel'],
      title: 'Book marketplace',
      snippet: 'Explore new and used books available through Amazon Canada.',
      url: 'https://www.amazon.ca/s?k=books',
    },
    {
      keywords: ['vpn', 'privacy', 'security'],
      title: 'Proton VPN',
      snippet: 'Review privacy-focused VPN options from Proton.',
      url: 'https://protonvpn.com',
    },
  ]

  const sponsored = partners
    .filter((partner) =>
      partner.keywords.some((keyword) => normalizedQuery.includes(keyword)),
    )
    .map<SearchResult>((partner) => ({
      ...partner,
      source: 'ALLMINE partner',
      type: 'sponsored',
    }))

  return [...sponsored, ...results]
}

function deduplicate(results: SearchResult[]) {
  const seen = new Set<string>()
  return results.filter((result) => {
    const key = `${result.title.toLowerCase()}|${result.url}`
    if (seen.has(key)) return false
    seen.add(key)
    return true
  })
}

export default async function search(req: Request, context: Context) {
  if (req.method !== 'POST') {
    return json({ success: false, error: 'METHOD_NOT_ALLOWED' }, 405)
  }

  let body: SearchBody
  try {
    body = (await req.json()) as SearchBody
  } catch {
    return json({ success: false, error: 'INVALID_JSON' }, 400)
  }

  const query = typeof body.query === 'string' ? body.query.trim() : ''
  const clientId = typeof body.clientId === 'string' ? body.clientId.trim() : ''

  if (!query || query.length > 160) {
    return json(
      { success: false, error: 'INVALID_QUERY', message: 'Enter a query up to 160 characters.' },
      400,
    )
  }

  if (!/^[a-zA-Z0-9-]{8,128}$/.test(clientId)) {
    return json({ success: false, error: 'INVALID_CLIENT' }, 400)
  }

  try {
    const visitorKey = getVisitorKey(clientId, context)
    const searches = await claimFreeSearch(visitorKey)

    if (searches === null) {
      return json(
        {
          success: false,
          error: 'FREE_LIMIT_REACHED',
          message: `All ${FREE_SEARCH_LIMIT} complimentary searches have been used on this device.`,
          price: `${PREMIUM_PRICE.toFixed(2)} CAD/year`,
        },
        402,
      )
    }

    const sourceResults = await Promise.all([
      fetchWikipedia(query),
      fetchDuckDuckGo(query),
    ])
    const results = addPartnerResults(query, deduplicate(sourceResults.flat()))

    return json({
      success: true,
      owner: 'Morley Moses Apooch',
      remaining: Math.max(0, FREE_SEARCH_LIMIT - searches),
      results,
    })
  } catch {
    return json(
      {
        success: false,
        error: 'SERVICE_UNAVAILABLE',
        message: 'The search matrix is temporarily unavailable. Please try again shortly.',
      },
      503,
    )
  }
}

export const config: Config = {
  path: '/api/search',
  method: 'POST',
}
