CREATE TABLE "search_usage" (
	"visitor_key" text PRIMARY KEY,
	"searches" integer DEFAULT 0 NOT NULL,
	"created_at" timestamp DEFAULT now() NOT NULL,
	"updated_at" timestamp DEFAULT now() NOT NULL
);
