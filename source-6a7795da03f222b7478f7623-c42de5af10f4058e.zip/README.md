# ALLMINE Search Matrix

ALLMINE is an independent search interface owned by Morley Moses Apooch of Yellow Quill First Nation. It combines public results from Wikipedia and DuckDuckGo in a focused, responsive web experience that deploys as one Netlify project.

## Technology

- TanStack Start and React 19 for the application interface
- Netlify Functions for the same-origin `/api/search` endpoint
- Netlify Database with Drizzle ORM for persistent complimentary-search usage
- Tailwind CSS and custom CSS for the visual system
- Wikipedia and DuckDuckGo public APIs as result sources

## Local Development

Install dependencies and start the development server:

```bash
pnpm install
pnpm dev
```

The application runs on the Vite development URL shown in the terminal. To emulate the deployed Netlify Function and Database behavior, use Netlify Dev from the project root:

```bash
netlify dev --port 8889
```

No third-party API key is required. Netlify provisions the managed database and applies the migration in `netlify/database/migrations/` during deployment.

## Deployment

The repository is configured for Netlify through `netlify.toml`. A production deployment builds the TanStack Start application, deploys the search function, and applies the database migration automatically.

The free tier currently allows five searches per browser device and network identity. Premium pricing is displayed in the interface, but payment enrollment is intentionally not connected until a checkout provider and fulfillment process are configured.
